def helloWorld():
	print('Hello my friends')
